import java.util.ArrayList;
public class Cpu extends Player {
    //This class is supposed to replicate the Player class, but use
    //automated inputs where user inputs would be
    
    //constructor
    public Cpu(String name){
        super(name);
        ArrayList<Card> hand = new ArrayList<Card>();
    }
    
    
    
    //new methods with similar purpose
    
    //meant to draw a card
    @Override
    public void drawCard(ArrayList<Card> deck){
            hand.add(deck.remove(0));
    }
    //return the hand
    public ArrayList<Card> computerHand(){
        return hand;
    }
    //play a selected card, different return value
        @Override
        public Card playCard(int choice){
            return hand.remove(choice);
        }
    //same method as player class but needs to have automated wild card
    @Override
    public boolean canPlay(ArrayList<Card> discard, int choice){
            if(discard.get(discard.size()-1).getNum().equals("card")){
                if(newColor==1){
                    if(hand.get(choice).getColor().equals("red")){
                        return true;
                    }
                } else if(newColor==2){
                    if(hand.get(choice).getColor().equals("green")){
                        return true;
                    }
                }else if(newColor==3){
                    if(hand.get(choice).getColor().equals("yellow")){
                        return true;
                    }
                }else if(newColor==4){
                    if(hand.get(choice).getColor().equals("blue")){
                        return true;
                    }
                }
            }
            if(hand.get(choice).getNum().equals(discard.get(discard.size()-1).getNum())||hand.get(choice).getColor().equals(discard.get(discard.size()-1).getColor())){
                return true;
            }else if(hand.get(choice).getNum().equals("card")){
                
                int newColor = (int)(Math.random()*4 + 1);
                if(newColor==1){
                    System.out.println("Current color, red");
                } else if(newColor==2){
                    System.out.println("Current color, green");
                }else if(newColor==3){
                    System.out.println("Current color, yellow");
                } else if(newColor==4){
                    System.out.println("Current color, blue");
                }
                return true;
            }else{
                return false;
            }
    }
}