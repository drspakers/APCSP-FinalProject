/*
Mini-Uno

This program runs a simulated 2 player uno, with the user against the computer
It includes a fully automated CPu and a modified uno deck with a couple less cards to keep the game shorter
When you run the code, everything should work unless you enter a letter or a number out of bounds

The deck is stored in an ArrayList of Card objects, and the discard in another.
The CPU inherits most of the methods from the Player class, but a few are modified to be automated.

The Card class is meant to create card objects stored in arrays. The cards class stores these cards and
has methods to modify the arrays. The Player class stores the player data, inputs, and current hand. The
CPU class inherits these purposes but instead uses modified methods to simulate player input.

When running the program, do NOT enter a letter into the code unless giving your name/starting the game.
Exception handling is not finished. Additionally, there is a bug when the computer plays a wild card, where 
it will not tell you the color that it switched too. All other cards, like skip and plus 2, work just like in
uno.

The program will finish running if someone wins or if the player declines to start the game.

This program was very tough to make as I did 80% at home, and the program had many bugs and issues to start.
Additionally, I did not have time to get to exception handling and I wish I coould have consolidated
some of the main method into more methods.

Below is a class diagram link to showcase the program.

https://drive.google.com/file/d/1ebG5LSjjHXevg5qQBSQjspogjpfIVItS/view?usp=sharing

*/