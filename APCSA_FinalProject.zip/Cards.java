import java.util.ArrayList;
import java.awt.Color;
public class Cards {
    //this class is meant to construct the decks and manipulate them
    //according to the game
    
    
    //discard pile
    private ArrayList<Card> discard;
    private ArrayList<Card> deck;
    //constructer to initialize the two arrays, creates the deck as well
    public Cards(ArrayList<Card> discard, ArrayList<Card> deck){
        this.discard = discard;
        this.deck = deck;
        this.createDeck();
    }
    //creates the deck using for loops to add a card for each color
    public void createDeck(){
        for( int numCards = 0; numCards < 5; numCards++){
            if(numCards ==0){
                for(int color =0; color <14; color++){
                    if(color<10){
                        String num = Integer.toString(color);
                        Card card = new Card(num, "green");
                        deck.add(card); 
                    }else if(color==10){
                        Card card = new Card("skip", "green");
                        deck.add(card); 
                    }else if(color==11){
                        Card card= new Card("reverse", "green");
                        deck.add(card); 
                    }else{
                        Card card = new Card("plus2", "green");
                        deck.add(card); 
                    }
                   
                }
            }else if(numCards ==1){
                for(int color =0; color <14; color++){
                    if(color<10){
                        String num = Integer.toString(color);
                        Card card = new Card(num, "blue");
                        deck.add(card); 
                    }else if(color==10){
                        Card card = new Card("skip", "blue");
                        deck.add(card); 
                    }else if(color==11){
                        Card card= new Card("reverse", "blue");
                        deck.add(card); 
                    }else{
                        Card card = new Card("plus2", "blue");
                        deck.add(card); 
                    }
                   
                }
            }else if(numCards ==2){
                for(int color =0; color <14; color++){
                    if(color<10){
                        String num = Integer.toString(color);
                        Card card = new Card(num, "yellow");
                        deck.add(card); 
                    }else if(color==10){
                        Card card = new Card("skip", "yellow");
                        deck.add(card); 
                    }else if(color==11){
                        Card card= new Card("reverse", "yellow");
                        deck.add(card); 
                    }else{
                        Card card = new Card("plus2", "yellow");
                        deck.add(card); 
                    }
                   
                }
            }else if(numCards ==3){
                for(int color =0; color <14; color++){
                    if(color<10){
                        String num = Integer.toString(color);
                        Card card = new Card(num, "red");
                        deck.add(card); 
                    }else if(color==10){
                        Card card = new Card("skip", "red");
                        deck.add(card); 
                    }else if(color==11){
                        Card card= new Card("reverse", "red");
                        deck.add(card); 
                    }else{
                        Card card = new Card("plus2", "red");
                        deck.add(card); 
                    }
                   
                }
            }else{
                for(int color = 0; color< 4; color++){
                    Card card = new Card("card", "wild");
                    deck.add(card);
                }
            
            }
        
        }
    }
    //methods
    //returns deck
    public ArrayList<Card> getDeck(){
        return deck;
    }
    //returns discard
    public ArrayList<Card> getDiscard(){
        return discard;
    }
    //shows the top card in the discard pile
    public Card topCard(){
        return discard.get(discard.size()-1);
    }
    //return true if the deck is empty
    public boolean isEmpty(){
        if(deck.size()==0){
            return true;
        }else{
            return false;
        }
    }
    //move the discard into the deck
    public void resetDeck(ArrayList<Card> deck, ArrayList<Card> discard){
        for(int i =0; i< discard.size(); i++){
            deck.add(discard.remove(0));
        }
        this.shuffle();
    }
    //shuffle the cards
    public void shuffle(){
        ArrayList<Card> placeholder = new ArrayList<Card>();
        for(int num = deck.size()-1; num >= 0; num--){
            int part = (int)(Math.random()*(num+1));
            placeholder.add(deck.remove(part));
        }
        for(Card card:placeholder){
            deck.add(card);
            
        }
    }
    //place the first card to start the game
    public void placeFirstCard(){
        int count = 0;
        if(deck.get(count).getNum().equals("card")){
            while(deck.get(count).getNum().equals("card")){
                count++;
            }
        }
        discard.add(deck.remove(count));
    }
}