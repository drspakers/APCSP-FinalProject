import java.awt.Color;
public class Card {
    //this class creates the cards needed for the deck
    
    //instance variables
    //num is a String so I can initiate the number as a skip or wild card
    private String num;
    private String color;
    //constructor
    public Card(String num, String color){
        this.num = num;
        this.color = color;

    }
    //getters only, no need to change card values
    public String getNum(){
        return num;
    }
    
    public String getColor(){
        return color;
    }
    
    //toString method
    public String toString(){
        return color +" " +  num;
    }
}