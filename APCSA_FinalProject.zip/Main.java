import java.util.ArrayList;
import java.awt.Color;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        //makes sure the skip only happens once
        int skip = 0;
        Scanner input = new Scanner(System.in);
        ArrayList<Card> deck = new ArrayList<Card>();
        ArrayList<Card> discard = new ArrayList<Card>();
        Cards game = new Cards(discard, deck);
        int turn = 0;
        System.out.println("What is your name?");
        String name = input.nextLine();
        Player p1 = new Player(name);
        Cpu comp = new Cpu("CPU");
        System.out.println("Start? Y/N");
        String decision = input.nextLine();
        if(decision.toLowerCase().equals("y")){
            game.shuffle();
            p1.dealHand(deck);
            comp.dealHand(deck);
            game.placeFirstCard();
        }
        while(decision.toLowerCase().equals("y")){
            
            if(turn%2==0){
                if(game.topCard().getNum().equals("plus2")){
                    p1.drawCard(deck);
                    p1.drawCard(deck);
                    p1.getHand();
                    System.out.println("You drew two cards");
                }else if(game.topCard().getNum().equals("skip")&&skip==0){
                    System.out.println("Your turn is skipped");
                    skip=1;
                    turn=1;
                }
                System.out.println("Your turn! Choose a card to pick by entering it's position in your hand or type 0 to draw a card");
                p1.getHand();
                System.out.println("Current card in play:" + game.topCard());
                
                
                while(turn%2==0){
                    int choice = input.nextInt();
                    //input.next();
                    if(choice == 0){
                        while(choice==0){
                            if(deck.size()<=0){
                                game.resetDeck(deck, discard);
                            }
                            p1.drawCard(deck);
                            p1.getHand();
                            System.out.println("Choose a new card or draw another.");
                            System.out.println("Current card in play:" + game.topCard());
                            choice = input.nextInt();
                        }
                    }
                    if(p1.canPlay(discard, choice)){
                        discard.add(p1.playCard(choice));
                        if(p1.isWinner()){
                            System.out.println("You win!");
                            decision = "n";
                        }
                        skip=0;
                        turn=1;
                        break;
                    }else{
                        System.out.println("You must choose a different card or draw a card");
                        
                    }
                    
                }
            }else if(turn%2!=0){
                while(turn%2!=0){
                    if(game.topCard().getNum().equals("plus2")){
                            comp.drawCard(deck);
                            comp.drawCard(deck);
                        }else if(game.topCard().getNum().equals("skip")&&skip==0){
                            System.out.println("You skipped the opponents turn");
                            skip=1;
                            turn=0;
                            break;
                    }
                    for(int i = 0; i < comp.computerHand().size()-1; i++){
                        
                        if(comp.canPlay(discard, i)){
                            discard.add(comp.playCard(i));
                            System.out.println("Your opponent played " + game.topCard());
                            if(comp.isWinner()){
                                System.out.println("You lose!");
                                decision = "n";
                            }
                            skip = 0;
                            turn = 0;
                            break;
                        }
                    if(deck.size()==0){
                        game.resetDeck(deck, discard);
                    }
                    
                    }
                    comp.drawCard(deck);
                }
            }
        }
        System.out.println("Thanks for playing, goodbye!");
    }
}