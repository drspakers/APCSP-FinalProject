import java.util.ArrayList;
import java.util.Scanner;
public class Player {
        //this is meant to create a player object and
        //take user inputs to play cards
        
        private String name;
        private int numCards;
        public int newColor;
        public ArrayList<Card> hand;
        
        //constructor
        public Player(String name){
            this.name = name;
            hand = new ArrayList<Card>();
        }
        
        //methods
        public String getName(){
            return name;
        }
        
        public void setName(String name){
            this.name= name;
        }
        
        
        //gives the player a hand of 7 random cards, call after shuffling deck
        public void dealHand(ArrayList<Card> deck){
            for(int i = 0; i<7; i++){
                hand.add(deck.remove(0));
            }
        }
        //returns number of cards left
        public int getCardsLeft(){
            return hand.size();
        }
        //draw a card
        public void drawCard(ArrayList<Card> deck){
            hand.add(deck.remove(0));
        }
        
        //place card
        public boolean canPlay(ArrayList<Card> discard, int choice){
            Scanner input = new Scanner(System.in);
            if(discard.get(discard.size()-1).getNum().equals("card")){
                if(newColor==1){
                    if(hand.get(choice-1).getColor().equals("red")){
                        return true;
                    }
                } else if(newColor==2){
                    if(hand.get(choice-1).getColor().equals("green")){
                        return true;
                    }
                }else if(newColor==3){
                    if(hand.get(choice-1).getColor().equals("yellow")){
                        return true;
                    }
                }else if(newColor==4){
                    if(hand.get(choice-1).getColor().equals("blue")){
                        return true;
                    }
                }
            }
            if(hand.get(choice-1).getNum().equals(discard.get(discard.size()-1).getNum())||hand.get(choice-1).getColor().equals(discard.get(discard.size()-1).getColor())){
                return true;
            }else if(hand.get(choice-1).getNum().equals("card")){
                System.out.println("Press 1 for red, 2 for green, 3 for yellow, and 4 for blue");
                newColor = input.nextInt();
                
                return true;
            }else{
                return false;
            }
        }
        //play a selected card
        public Card playCard(int choice){
            return hand.remove(choice-1);
        }
        //return hand
        public void getHand(){
            System.out.println(hand);
        }
        
        //return true if they are out of cards and false otherwise
        public boolean isWinner(){
            if(hand.size()==0){
                return true;
            }else{
                return false;
            }
        }
    }